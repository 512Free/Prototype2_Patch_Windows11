/* Minimal 32-bit host that loads the proxy dbghelp.dll from the game folder
 * and checks: exports resolve, forwarding works, affinity is clamped,
 * IAT hook on this exe works. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

typedef DWORD64 (WINAPI *SymGMB64_t)(HANDLE, DWORD64);

static int popcount(DWORD_PTR m) { int n = 0; while (m) { n += (int)(m & 1); m >>= 1; } return n; }

int main(int argc, char** argv)
{
    DWORD_PTR pm = 0, sm = 0;
    HMODULE h; SymGMB64_t gmb; DWORD64 base;
    if (argc < 2) { printf("usage: testhost <path to dbghelp.dll>\n"); return 2; }

    GetProcessAffinityMask(GetCurrentProcess(), &pm, &sm);
    printf("before: process mask 0x%08lX (%d cores)\n", (unsigned long)pm, popcount(pm));

    h = LoadLibraryA(argv[1]);
    if (!h) { printf("FAIL: LoadLibrary %lu\n", GetLastError()); return 1; }
    printf("loaded %s\n", argv[1]);

    gmb = (SymGMB64_t)GetProcAddress(h, "SymGetModuleBase64");
    if (!gmb || !GetProcAddress(h, "StackWalk64") || !GetProcAddress(h, "SymFunctionTableAccess64")) {
        printf("FAIL: exports missing\n"); return 1;
    }
    {   /* SymGetModuleBase64 needs SymInitialize on the real dbghelp first */
        char sys[MAX_PATH]; HMODULE real;
        typedef BOOL (WINAPI *SymInit_t)(HANDLE, const char*, BOOL);
        GetSystemDirectoryA(sys, MAX_PATH); lstrcatA(sys, "\\dbghelp.dll");
        real = LoadLibraryA(sys);
        if (!real || !((SymInit_t)GetProcAddress(real, "SymInitialize"))(GetCurrentProcess(), NULL, TRUE)) {
            printf("FAIL: SymInitialize on real dbghelp\n"); return 1;
        }
    }
    base = gmb(GetCurrentProcess(), (DWORD64)(DWORD_PTR)&main);
    printf("SymGetModuleBase64(&main) = 0x%08llX (expect 0x%08lX)\n", base, (unsigned long)(DWORD_PTR)GetModuleHandleA(NULL));
    if (base != (DWORD64)(DWORD_PTR)GetModuleHandleA(NULL)) { printf("FAIL: forwarding\n"); return 1; }

    GetProcessAffinityMask(GetCurrentProcess(), &pm, &sm);
    printf("after:  process mask 0x%08lX (%d cores), system mask 0x%08lX (%d cores)\n",
           (unsigned long)pm, popcount(pm), (unsigned long)sm, popcount(sm));
    if (popcount(pm) > 8) { printf("FAIL: affinity not clamped\n"); return 1; }
    printf("OK\n");
    return 0;
}
