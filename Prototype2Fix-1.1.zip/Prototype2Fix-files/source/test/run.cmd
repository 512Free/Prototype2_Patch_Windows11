@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul 2>&1
cd /d "%~dp0"
cl /nologo /W4 testhost.c /link kernel32.lib /NOLOGO
if errorlevel 1 exit /b 1
dir /b
testhost.exe "%~dp0dbghelp.dll"
set RC=%errorlevel%
echo --- log ---
type Prototype2Fix.log
exit /b %RC%
