@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul
cd /d "%~dp0"
cl /nologo /O2 /W4 /MT /D_CRT_SECURE_NO_WARNINGS Prototype2Fix.c /link /DLL /DEF:Prototype2Fix.def /OUT:dbghelp.dll kernel32.lib /NOLOGO
if errorlevel 1 exit /b 1
del *.obj *.exp *.lib 2>nul
echo Built dbghelp.dll
