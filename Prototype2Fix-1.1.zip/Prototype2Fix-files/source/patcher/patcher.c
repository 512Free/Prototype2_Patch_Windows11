/*
 * Prototype 2 Fix - Patcher (classic Win32 GUI)
 *
 * Installs/uninstalls the Prototype2Fix proxy DLL (dbghelp.dll) and its ini
 * into the game folder. The DLL and ini are embedded as resources so the
 * patcher is a single exe.
 *
 *   - finds the game via Steam (registry + libraryfolders.vdf)
 *   - verifies the game build (prototype2engine.dll PE timestamp)
 *   - backs up any existing dbghelp.dll / Prototype2Fix.ini to
 *     Prototype2Fix_backup\ before overwriting
 *   - writes the files and verifies them with CRC32
 *   - uninstall restores the backup (or just removes the files)
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"

#define SUPPORTED_ENGINE_TIMESTAMP 0x68B09A3Aul   /* prototype2engine.dll, Steam build 2025-08-28 */
#define STEAM_APPID               "115320"
#define BACKUP_DIR                "Prototype2Fix_backup"
#define FIX_DLL                   "dbghelp.dll"
#define FIX_INI                   "Prototype2Fix.ini"

static HINSTANCE g_hInst;
static HWND g_hDlg;
static char g_gameDir[MAX_PATH];

/* ---------------- logging / ui helpers ---------------- */
static void LogLine(const char* fmt, ...)
{
    char buf[1024]; va_list ap; int len; HWND h = GetDlgItem(g_hDlg, IDC_LOG);
    va_start(ap, fmt); len = _vsnprintf(buf, sizeof(buf) - 3, fmt, ap); va_end(ap);
    if (len < 0) len = (int)strlen(buf);
    buf[len] = '\r'; buf[len + 1] = '\n'; buf[len + 2] = 0;
    SendMessageA(h, EM_SETSEL, (WPARAM)-1, (LPARAM)-1);
    SendMessageA(h, EM_REPLACESEL, FALSE, (LPARAM)buf);
    SendMessageA(h, EM_SCROLLCARET, 0, 0);
    UpdateWindow(h);
}
static void SetProgress(int pct)
{
    SendMessageA(GetDlgItem(g_hDlg, IDC_PROGRESS), PBM_SETPOS, pct, 0);
    UpdateWindow(GetDlgItem(g_hDlg, IDC_PROGRESS));
}
static void SetStatus(int id, const char* text) { SetDlgItemTextA(g_hDlg, id, text); }

/* ---------------- CRC32 ---------------- */
static DWORD g_crcTable[256];
static void CrcInit(void)
{
    DWORD i, j, c;
    for (i = 0; i < 256; i++) {
        c = i;
        for (j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320ul ^ (c >> 1)) : (c >> 1);
        g_crcTable[i] = c;
    }
}
static DWORD CrcBuf(const BYTE* p, DWORD n, DWORD crc)
{
    DWORD i; crc = ~crc;
    for (i = 0; i < n; i++) crc = g_crcTable[(crc ^ p[i]) & 0xFF] ^ (crc >> 8);
    return ~crc;
}
static int CrcFile(const char* path, DWORD* outCrc, DWORD* outSize)
{
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    BYTE buf[65536]; DWORD got, crc = 0, size = 0;
    if (h == INVALID_HANDLE_VALUE) return 0;
    while (ReadFile(h, buf, sizeof(buf), &got, NULL) && got) { crc = CrcBuf(buf, got, crc); size += got; }
    CloseHandle(h);
    *outCrc = crc; if (outSize) *outSize = size;
    return 1;
}

/* ---------------- embedded resources ---------------- */
static const BYTE* GetRes(int id, DWORD* size)
{
    HRSRC r = FindResourceA(g_hInst, MAKEINTRESOURCEA(id), (LPCSTR)RT_RCDATA);
    HGLOBAL g; if (!r) return NULL;
    g = LoadResource(g_hInst, r); if (!g) return NULL;
    *size = SizeofResource(g_hInst, r);
    return (const BYTE*)LockResource(g);
}
static int WriteFileBytes(const char* path, const BYTE* data, DWORD size)
{
    HANDLE h = CreateFileA(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    DWORD wrote = 0; BOOL ok;
    if (h == INVALID_HANDLE_VALUE) return 0;
    ok = WriteFile(h, data, size, &wrote, NULL);
    CloseHandle(h);
    return ok && wrote == size;
}

/* ---------------- game detection ---------------- */
static int FileExists(const char* path) { DWORD a = GetFileAttributesA(path); return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY); }
static void PathJoin(char* out, const char* dir, const char* file)
{
    lstrcpyA(out, dir);
    if (out[0] && out[lstrlenA(out) - 1] != '\\') lstrcatA(out, "\\");
    lstrcatA(out, file);
}
static int IsGameDir(const char* dir)
{
    char p[MAX_PATH]; PathJoin(p, dir, "prototype2.exe"); if (!FileExists(p)) return 0;
    PathJoin(p, dir, "prototype2engine.dll"); return FileExists(p);
}
static int RegReadString(HKEY root, const char* key, const char* value, char* out, DWORD cb, REGSAM extra)
{
    HKEY h; DWORD type = 0; LONG r;
    if (RegOpenKeyExA(root, key, 0, KEY_READ | extra, &h) != ERROR_SUCCESS) return 0;
    r = RegQueryValueExA(h, value, NULL, &type, (BYTE*)out, &cb);
    RegCloseKey(h);
    return r == ERROR_SUCCESS && (type == REG_SZ || type == REG_EXPAND_SZ);
}
/* parse "path" entries in libraryfolders.vdf and test each library */
static int FindInLibraries(const char* steamPath, char* out)
{
    char vdf[MAX_PATH], cand[MAX_PATH]; HANDLE h; DWORD size, got; char* text; char* p;
    PathJoin(vdf, steamPath, "steamapps\\libraryfolders.vdf");
    h = CreateFileA(vdf, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) return 0;
    size = GetFileSize(h, NULL);
    text = (char*)LocalAlloc(LPTR, size + 1);
    if (!text) { CloseHandle(h); return 0; }
    ReadFile(h, text, size, &got, NULL); text[got] = 0; CloseHandle(h);
    for (p = text; (p = strstr(p, "\"path\"")) != NULL; ) {
        char* q; char* e; char lib[MAX_PATH]; int i, n = 0;
        p += 6;
        q = strchr(p, '"'); if (!q) break;
        q++; e = strchr(q, '"'); if (!e) break;
        for (i = 0; q + i < e && n < MAX_PATH - 1; i++) {   /* unescape \\ */
            if (q[i] == '\\' && q[i + 1] == '\\') { lib[n++] = '\\'; i++; }
            else lib[n++] = q[i];
        }
        lib[n] = 0;
        PathJoin(cand, lib, "steamapps\\common\\Prototype 2");
        if (IsGameDir(cand)) { lstrcpyA(out, cand); LocalFree(text); return 1; }
        p = e;
    }
    LocalFree(text);
    return 0;
}
static int AutoDetect(char* out)
{
    char steam[MAX_PATH], cand[MAX_PATH], exe[MAX_PATH]; int i;
    /* 1. Steam libraries */
    if (RegReadString(HKEY_CURRENT_USER, "Software\\Valve\\Steam", "SteamPath", steam, sizeof(steam), 0)) {
        for (i = 0; steam[i]; i++) if (steam[i] == '/') steam[i] = '\\';
        if (FindInLibraries(steam, out)) return 1;
        PathJoin(cand, steam, "steamapps\\common\\Prototype 2");
        if (IsGameDir(cand)) { lstrcpyA(out, cand); return 1; }
    }
    /* 2. Activision install key (written by Steam's installscript) */
    if (RegReadString(HKEY_LOCAL_MACHINE, "SOFTWARE\\Activision\\Prototype 2", "installpath", cand, sizeof(cand), KEY_WOW64_32KEY) && IsGameDir(cand)) { lstrcpyA(out, cand); return 1; }
    /* 3. the patcher's own folder */
    GetModuleFileNameA(NULL, exe, MAX_PATH);
    { char* s = strrchr(exe, '\\'); if (s) *s = 0; }
    if (IsGameDir(exe)) { lstrcpyA(out, exe); return 1; }
    return 0;
}

/* ---------------- game build check ---------------- */
static DWORD GetPeTimestamp(const char* path)
{
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    BYTE hdr[0x400]; DWORD got, e_lfanew, ts = 0;
    if (h == INVALID_HANDLE_VALUE) return 0;
    if (ReadFile(h, hdr, sizeof(hdr), &got, NULL) && got >= 0x40 && hdr[0] == 'M' && hdr[1] == 'Z') {
        e_lfanew = *(DWORD*)(hdr + 0x3C);
        if (e_lfanew + 12 <= got && *(DWORD*)(hdr + e_lfanew) == 0x00004550) ts = *(DWORD*)(hdr + e_lfanew + 8);
    }
    CloseHandle(h);
    return ts;
}

/* ---------------- status ---------------- */
typedef struct { int gameOk; DWORD engineTs; int buildOk; int dllPresent; int dllIsOurs; int iniPresent; int backupPresent; } Status;

static void CheckStatus(Status* s, int verbose)
{
    char p[MAX_PATH], msg[256]; DWORD resSize, resCrc = 0, fileCrc = 0, fileSize = 0; const BYTE* res;
    ZeroMemory(s, sizeof(*s));
    GetDlgItemTextA(g_hDlg, IDC_GAMEDIR, g_gameDir, MAX_PATH);
    s->gameOk = g_gameDir[0] && IsGameDir(g_gameDir);
    if (!s->gameOk) {
        SetStatus(IDC_ST_BUILD, "prototype2.exe / prototype2engine.dll not found in this folder");
        SetStatus(IDC_ST_PATCH, "-"); SetStatus(IDC_ST_BACKUP, "-");
        if (verbose) LogLine("Not a valid game folder: %s", g_gameDir[0] ? g_gameDir : "(empty)");
        return;
    }
    PathJoin(p, g_gameDir, "prototype2engine.dll");
    s->engineTs = GetPeTimestamp(p);
    s->buildOk = (s->engineTs == SUPPORTED_ENGINE_TIMESTAMP);
    _snprintf(msg, sizeof(msg), "timestamp 0x%08lX - %s", (unsigned long)s->engineTs,
              s->buildOk ? "Steam 2025-08-28 (supported)" : "UNKNOWN BUILD (the patch disables itself)");
    SetStatus(IDC_ST_BUILD, msg);

    PathJoin(p, g_gameDir, FIX_DLL);
    s->dllPresent = FileExists(p);
    res = GetRes(IDR_FIX_DLL, &resSize);
    if (res) resCrc = CrcBuf(res, resSize, 0);
    if (s->dllPresent && CrcFile(p, &fileCrc, &fileSize)) s->dllIsOurs = (fileCrc == resCrc && fileSize == resSize);
    PathJoin(p, g_gameDir, FIX_INI);
    s->iniPresent = FileExists(p);
    if (s->dllIsOurs) _snprintf(msg, sizeof(msg), "INSTALLED (dbghelp.dll CRC %08lX OK%s)", (unsigned long)fileCrc, s->iniPresent ? ", ini present" : ", ini MISSING");
    else if (s->dllPresent) _snprintf(msg, sizeof(msg), "foreign dbghelp.dll in game folder (CRC %08lX) - will be backed up when patching", (unsigned long)fileCrc);
    else lstrcpyA(msg, "not installed");
    SetStatus(IDC_ST_PATCH, msg);

    PathJoin(p, g_gameDir, BACKUP_DIR "\\" FIX_DLL);
    s->backupPresent = FileExists(p);
    PathJoin(p, g_gameDir, BACKUP_DIR);
    SetStatus(IDC_ST_BACKUP, s->backupPresent ? "present (original files saved in " BACKUP_DIR "\\)" :
              (GetFileAttributesA(p) != INVALID_FILE_ATTRIBUTES ? "folder exists, nothing to restore" : "none (no files needed saving)"));
    if (verbose) {
        LogLine("Game folder: %s", g_gameDir);
        LogLine("Build: 0x%08lX (%s)", (unsigned long)s->engineTs, s->buildOk ? "supported" : "unknown");
        LogLine("Patch: %s", s->dllIsOurs ? "installed" : s->dllPresent ? "foreign dbghelp.dll" : "not installed");
    }
    EnableWindow(GetDlgItem(g_hDlg, IDC_PATCH), s->gameOk);
    EnableWindow(GetDlgItem(g_hDlg, IDC_UNPATCH), s->gameOk && (s->dllPresent || s->iniPresent));
}

/* ---------------- patch / unpatch ---------------- */
static int BackupFile(const char* name)
{
    char src[MAX_PATH], dir[MAX_PATH], dst[MAX_PATH];
    PathJoin(src, g_gameDir, name);
    if (!FileExists(src)) return 1;
    PathJoin(dir, g_gameDir, BACKUP_DIR);
    CreateDirectoryA(dir, NULL);
    PathJoin(dst, dir, name);
    if (!CopyFileA(src, dst, FALSE)) { LogLine("  ERROR: could not back up %s (error %lu)", name, GetLastError()); return 0; }
    LogLine("  backup: %s -> %s\\%s", name, BACKUP_DIR, name);
    return 1;
}

static void DoPatch(void)
{
    Status s; char p[MAX_PATH]; const BYTE* res; DWORD resSize, resCrc, fileCrc, fileSize;
    SetProgress(0);
    LogLine("=== Patching ===");
    CheckStatus(&s, 0);
    if (!s.gameOk) { LogLine("Aborting: invalid game folder."); return; }
    if (!s.buildOk) {
        if (MessageBoxA(g_hDlg, "The game build is not the one this patch was made for.\n"
            "The patch will be installed but disables itself if the code does not match.\n\nContinue anyway?",
            "Unknown build", MB_ICONWARNING | MB_YESNO) != IDYES) { LogLine("Cancelled by user."); return; }
    }
    if (s.dllIsOurs && s.iniPresent) {
        if (MessageBoxA(g_hDlg, "The patch is already installed and verified.\nReinstall anyway?", "Already installed", MB_ICONQUESTION | MB_YESNO) != IDYES) { LogLine("Already installed - nothing done."); return; }
    }
    SetProgress(10);
    LogLine("Step 1/4: backup");
    if (s.dllPresent && !s.dllIsOurs) {          /* some other mod's dbghelp.dll: keep it (and its ini) */
        if (!BackupFile(FIX_DLL)) return;
        if (s.iniPresent && !BackupFile(FIX_INI)) return;
    }
    else if (s.dllPresent) LogLine("  existing dbghelp.dll is ours - no backup needed");
    else LogLine("  no dbghelp.dll present - no backup needed");
    SetProgress(35);

    LogLine("Step 2/4: writing " FIX_DLL);
    res = GetRes(IDR_FIX_DLL, &resSize);
    if (!res) { LogLine("  ERROR: embedded DLL missing from patcher"); return; }
    resCrc = CrcBuf(res, resSize, 0);
    PathJoin(p, g_gameDir, FIX_DLL);
    if (!WriteFileBytes(p, res, resSize)) { LogLine("  ERROR: could not write %s (error %lu). Try running the patcher as administrator.", p, GetLastError()); return; }
    SetProgress(60);

    LogLine("Step 3/4: writing " FIX_INI);
    res = GetRes(IDR_FIX_INI, &resSize);
    PathJoin(p, g_gameDir, FIX_INI);
    if (s.iniPresent) LogLine("  existing ini kept (your settings)");
    else if (!res || !WriteFileBytes(p, res, resSize)) { LogLine("  ERROR: could not write %s", p); return; }
    SetProgress(80);

    LogLine("Step 4/4: verifying");
    PathJoin(p, g_gameDir, FIX_DLL);
    res = GetRes(IDR_FIX_DLL, &resSize); resCrc = CrcBuf(res, resSize, 0);
    if (!CrcFile(p, &fileCrc, &fileSize) || fileCrc != resCrc || fileSize != resSize) {
        LogLine("  ERROR: verification failed (CRC %08lX, expected %08lX)", (unsigned long)fileCrc, (unsigned long)resCrc);
        return;
    }
    LogLine("  dbghelp.dll: %lu byte, CRC32 %08lX - OK", (unsigned long)fileSize, (unsigned long)fileCrc);
    SetProgress(100);
    LogLine("DONE. Launch the game through Steam as usual. Prototype2Fix.log in the game folder shows the result.");
    CheckStatus(&s, 0);
}

static void DoUnpatch(void)
{
    Status s; char p[MAX_PATH], b[MAX_PATH];
    SetProgress(0);
    LogLine("=== Uninstalling ===");
    CheckStatus(&s, 0);
    if (!s.gameOk) { LogLine("Aborting: invalid game folder."); return; }
    if (s.dllPresent && !s.dllIsOurs && !s.backupPresent) {
        if (MessageBoxA(g_hDlg, "The dbghelp.dll in the game folder is not the patch's and there is no backup.\nRemove it anyway?", "Warning", MB_ICONWARNING | MB_YESNO) != IDYES) { LogLine("Cancelled."); return; }
    }
    SetProgress(30);
    PathJoin(p, g_gameDir, FIX_DLL);
    PathJoin(b, g_gameDir, BACKUP_DIR "\\" FIX_DLL);
    if (FileExists(b)) {
        if (CopyFileA(b, p, FALSE)) { LogLine("  restored dbghelp.dll from backup"); DeleteFileA(b); }
        else LogLine("  ERROR: could not restore dbghelp.dll (error %lu)", GetLastError());
    } else if (FileExists(p)) {
        if (DeleteFileA(p)) LogLine("  removed dbghelp.dll"); else LogLine("  ERROR: could not remove dbghelp.dll (error %lu) - is the game running?", GetLastError());
    }
    SetProgress(60);
    PathJoin(p, g_gameDir, FIX_INI);
    PathJoin(b, g_gameDir, BACKUP_DIR "\\" FIX_INI);
    if (FileExists(b)) { CopyFileA(b, p, FALSE); DeleteFileA(b); LogLine("  restored Prototype2Fix.ini from backup"); }
    else if (FileExists(p)) { DeleteFileA(p); LogLine("  removed Prototype2Fix.ini"); }
    PathJoin(b, g_gameDir, BACKUP_DIR); RemoveDirectoryA(b);   /* only succeeds if empty */
    SetProgress(100);
    LogLine("DONE. Log files (Prototype2Fix*.log) are left in place.");
    CheckStatus(&s, 0);
}

/* ---------------- browse / launch ---------------- */
static void DoBrowse(void)
{
    OPENFILENAMEA ofn; char file[MAX_PATH] = "";
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn); ofn.hwndOwner = g_hDlg;
    ofn.lpstrFilter = "prototype2.exe\0prototype2.exe\0All files\0*.*\0";
    ofn.lpstrFile = file; ofn.nMaxFile = MAX_PATH;
    ofn.lpstrTitle = "Select prototype2.exe in the game folder";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
    if (GetOpenFileNameA(&ofn)) {
        char* s = strrchr(file, '\\'); if (s) *s = 0;
        SetDlgItemTextA(g_hDlg, IDC_GAMEDIR, file);
        { Status st; CheckStatus(&st, 1); }
    }
}
static void DoLaunch(void)
{
    Status s; CheckStatus(&s, 0);
    if (!s.dllIsOurs && MessageBoxA(g_hDlg, "The patch is not installed. Launch the game anyway?", "Launch game", MB_ICONQUESTION | MB_YESNO) != IDYES) return;
    LogLine("Launching the game through Steam (steam://rungameid/" STEAM_APPID ")...");
    ShellExecuteA(g_hDlg, "open", "steam://rungameid/" STEAM_APPID, NULL, NULL, SW_SHOWNORMAL);
}

/* ---------------- dialog ---------------- */
static INT_PTR CALLBACK DlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    (void)lParam;
    switch (msg) {
    case WM_INITDIALOG: {
        char dir[MAX_PATH]; Status s;
        g_hDlg = hDlg;
        SendMessageA(GetDlgItem(hDlg, IDC_PROGRESS), PBM_SETRANGE, 0, MAKELPARAM(0, 100));
        SendMessageA(GetDlgItem(hDlg, IDC_LOG), EM_SETLIMITTEXT, 0x7FFFF, 0);
        LogLine("Prototype 2 Fix - Patcher v1.1");
        LogLine("Fixes the crash after 'Press Enter' in the 2025 Steam build (the game mounts no archives).");
        if (AutoDetect(dir)) { SetDlgItemTextA(hDlg, IDC_GAMEDIR, dir); LogLine("Found the game: %s", dir); }
        else LogLine("Could not find the game automatically - pick the folder with Browse...");
        CheckStatus(&s, 0);
        return TRUE;
    }
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDC_PATCH:      DoPatch(); return TRUE;
        case IDC_UNPATCH:    DoUnpatch(); return TRUE;
        case IDC_CHECK:    { Status s; CheckStatus(&s, 1); return TRUE; }
        case IDC_BROWSE:     DoBrowse(); return TRUE;
        case IDC_AUTODETECT: {
            char dir[MAX_PATH]; Status s;
            if (AutoDetect(dir)) { SetDlgItemTextA(hDlg, IDC_GAMEDIR, dir); LogLine("Found the game: %s", dir); }
            else LogLine("Could not find the game automatically.");
            CheckStatus(&s, 0); return TRUE;
        }
        case IDC_LAUNCH:     DoLaunch(); return TRUE;
        case IDC_GAMEDIR:
            if (HIWORD(wParam) == EN_KILLFOCUS) { Status s; CheckStatus(&s, 0); }
            return TRUE;
        case IDC_EXIT: case IDCANCEL: EndDialog(hDlg, 0); return TRUE;
        }
        break;
    case WM_CLOSE: EndDialog(hDlg, 0); return TRUE;
    }
    return FALSE;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmd, int show)
{
    INITCOMMONCONTROLSEX icc = { sizeof(icc), ICC_PROGRESS_CLASS };
    (void)hPrev; (void)cmd; (void)show;
    g_hInst = hInst;
    CrcInit();
    InitCommonControlsEx(&icc);
    DialogBoxParamA(hInst, MAKEINTRESOURCEA(IDD_MAIN), NULL, DlgProc, 0);
    return 0;
}
