@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul 2>&1
cd /d "%~dp0"
if not exist "..\dbghelp.dll" (
    echo Bygger forst dbghelp.dll...
    call "..\build.cmd"
    if errorlevel 1 exit /b 1
)
copy /y "..\dbghelp.dll" dbghelp.dll >nul
copy /y "..\Prototype2Fix.ini" Prototype2Fix.ini >nul
rc /nologo patcher.rc
if errorlevel 1 exit /b 1
cl /nologo /O2 /W4 /MT /D_CRT_SECURE_NO_WARNINGS patcher.c patcher.res /link /SUBSYSTEM:WINDOWS /OUT:Prototype2Fix-Patcher.exe user32.lib gdi32.lib comctl32.lib comdlg32.lib advapi32.lib shell32.lib /NOLOGO
if errorlevel 1 exit /b 1
del *.obj *.res dbghelp.dll Prototype2Fix.ini 2>nul
echo Built Prototype2Fix-Patcher.exe
