#define IDD_MAIN        100
#define IDR_FIX_DLL     200
#define IDR_FIX_INI     201

#define IDC_HEADER      1001
#define IDC_GAMEDIR     1002
#define IDC_BROWSE      1003
#define IDC_AUTODETECT  1004
#define IDC_ST_BUILD    1005
#define IDC_ST_PATCH    1006
#define IDC_ST_BACKUP   1007
#define IDC_PROGRESS    1008
#define IDC_LOG         1009
#define IDC_PATCH       1010
#define IDC_UNPATCH     1011
#define IDC_LAUNCH      1012
#define IDC_EXIT        1013
#define IDC_CHECK       1014
