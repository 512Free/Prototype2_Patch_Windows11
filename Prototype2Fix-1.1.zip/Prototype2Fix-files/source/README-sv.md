# Prototype2Fix – kör PROTOTYPE 2 (Steam, 2025-builden) på Windows 11

## Symptom
Spelet startar, visar logotyper och kraschar några sekunder senare (vid
"Press Enter"). Händelseloggen visar `APPCRASH`, `prototype2engine.dll`,
undantag `0xc0000005`, felförskjutning `0x00567a80`. Det händer både via Steam
och vid direktstart, oavsett CPU-affinitet, `Windowed` m.m.

## Grundorsak (hittad genom disassemblering av `prototype2engine.dll`)
Steam-builden från 2025 (`Build R on 08/28`, PE-timestamp `0x68B09A3A`,
Steam buildid 19788008) har ett trasigt arkivsystem:

1. `ArchiveSystem::Init` (RVA `0x689320`) monterar spelets `.rcf`-arkiv
   ("cement files") från listan i **`cementfiles.p3d`** – en fil som
   **inte finns i Steam-depån**. Init monterar därför ingenting.
2. Reservvägen – en kooperativ fiber ("Cement Thread") som skannar
   `<katalog>\*.rcf` – startar aldrig, eftersom ingen kod i den här builden
   sätter flaggan "skanning begärd" (RVA `0xE19864`). Dessutom skulle den
   skanna `downloads\`, inte spelmappen.
3. Utan monterade arkiv faller varje laddning tillbaka på lösa filer på disk
   (`art\hud\main.gfx` …) som inte finns. Scaleforms
   `GFxLoader::CreateMovie("main.gfx")` returnerar NULL och motorn anropar
   en virtuell metod på NULL-pekaren → krasch vid `0x10567A80`.

(Den klassiska "för många CPU-kärnor"-kraschen gäller äldre builds; den
hanteras också, men den är inte orsaken här.)

## Vad modden gör
`dbghelp.dll` i spelmappen är en *proxy-DLL*: motorn importerar tre
funktioner från dbghelp och Windows söker spelmappen först, så DLL:n laddas
automatiskt innan motorn initieras. Den vidarebefordrar de tre anropen till
riktiga `SysWOW64\dbghelp.dll` och gör dessutom:

- **MountFix** (huvudfixen): två engångs-brytpunkter (int3 + vectored
  exception handler, inga spelfiler ändras):
  - vid `ArchiveSystem::Init`: skannkatalogen i init-strukturen byts från
    `downloads` till `.` (spelmappen);
  - direkt efter Init (RVA `0x685600`, huvudtråden, före första
    HUD-laddningen): flaggan "skanning begärd" sätts och motorns egen
    `ArchiveSystem::Pump()` (RVA `0x688BD0`) körs växelvis med
    `UpdateAllDrives()` (RVA `0x6888C0`, det som real-time-tasken gör varje
    frame för att driva fil-I/O) tills fibern rapporterar klart. Alla elva
    `.rcf`-arkiv monteras då på ~100 ms.
  Fixen aktiveras bara om DLL:ns PE-timestamp och kodbytes på patchpunkterna
  stämmer, så en framtida uppdatering av spelet stänger av den (loggas) i
  stället för att krascha.
- CPU-affinitet begränsas till `MaxCores` (standard 8) + hook på
  `GetProcessAffinityMask`.
- Kraschlogg (`Prototype2Fix_crash.log`): undantag, register, stack med
  modul-offset och strängar, alla trådars position.
- Valfri I/O-spårning (`TraceFiles=1`): loggar `CreateFileA`, `FindFirstFileA`,
  `ReadFile` och `OutputDebugString`.

Varför inte `winmm.dll` som proxy? Steams overlay (`GameOverlayRenderer.dll`)
importerar själv winmm och laddas före spelet – en winmm-proxy i spelmappen
hade aldrig använts. dbghelp är inte en KnownDLL och berörs inte av overlayen.

## Installation – enklast: patchern
Kör **`Prototype2Fix-Patcher.exe`** (klassiskt Win32-program, inga beroenden):

- hittar spelet automatiskt via Steams register + `libraryfolders.vdf`
  (eller via `Bläddra...` → välj `prototype2.exe`);
- visar spelets build (PE-timestamp på `prototype2engine.dll`) och om den
  stöds, samt om patchen redan är installerad (CRC32-kontroll av `dbghelp.dll`);
- **Patcha**: tar backup av en ev. främmande `dbghelp.dll`/ini till
  `Prototype2Fix_backup\`, skriver de inbäddade filerna, verifierar med CRC32;
- **Avinstallera**: återställer backupen eller tar bort filerna;
- **Kontrollera** / **Starta spelet** (via `steam://rungameid/115320`).

Patchern bygger du med `patcher\build.cmd` (bäddar in `dbghelp.dll` och
`Prototype2Fix.ini` som resurser).

## Installation – manuellt
Lägg dessa två filer bredvid `prototype2.exe` (i Steam-mappen
`...\steamapps\common\Prototype 2`):

- `dbghelp.dll`
- `Prototype2Fix.ini`

Starta spelet via Steam som vanligt (eller med `Starta Prototype 2.bat`).
`Prototype2Fix.log` i spelmappen visar vad som hände, t.ex.
`mountfix: archives mounted after 38 pump iterations, 94 ms`.

Avinstallation: ta bort `dbghelp.dll`.

## Inställningar (`Prototype2Fix.ini`)
| Nyckel | Standard | Beskrivning |
|---|---|---|
| `MountFix` | 1 | Montera arkiven vid start (själva fixen). |
| `MaxCores` | 8 | Max logiska processorer. 64 = ingen begränsning. |
| `LimitProcessAffinity` | 1 | Begränsa processen på riktigt. |
| `FakeAffinityMask` | 1 | Låt motorn se högst MaxCores. |
| `CrashLog` | 1 | Skriv `Prototype2Fix_crash.log` vid krasch. |
| `Log` | 1 | Skriv `Prototype2Fix.log` vid varje start. |
| `TraceFiles` | 0 | Logga fil-I/O (felsökning). |

## Bygga själv
Kräver Visual Studio med x86-verktyg. Kör `build.cmd` – den skapar
`dbghelp.dll` i samma mapp. Kopiera den till spelmappen.
`test\run.cmd` bygger ett testprogram som laddar DLL:n och kontrollerar
forwarding + kärnbegränsning.

## Filer
- `Prototype2Fix.c` – all källkod (kommenterad med RVA:er och motorns semantik)
- `Prototype2Fix.def` – exporterade dbghelp-funktioner
- `build.cmd` – byggskript (MSVC x86)
- `test/` – testprogram
