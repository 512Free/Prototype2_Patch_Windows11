/*
 * Prototype2Fix - dbghelp.dll proxy for PROTOTYPE 2 (Steam, 2025 build)
 *
 * ROOT CAUSE (found by disassembling prototype2engine.dll, build 2025-08-28,
 * PE timestamp 0x68B09A3A):
 *   The archive system (ArchiveSystem::Init @ RVA 0x689320) mounts the game's
 *   .rcf "cement" archives from a list in cementfiles.p3d - a file the Steam
 *   depot does not ship.  The fallback - a cooperative "Cement Thread" fiber
 *   that scans <dir>\*.rcf - is never started because nothing in this build
 *   sets the scan-requested flag (RVA 0xE19864), and it would scan
 *   "downloads\" instead of the game folder anyway.  Result: no archive is
 *   mounted, every asset load falls back to loose files that do not exist,
 *   Scaleform's CreateMovie("art\hud\main.gfx") returns NULL and the engine
 *   dereferences it at RVA 0x567A80 (the APPCRASH offset in Event Viewer).
 *
 * THE FIX (MountFix=1):
 *   1. At ArchiveSystem::Init entry, change the init struct's scan directory
 *      from "downloads" to "." (the game folder).
 *   2. Right after Init returns (RVA 0x685600, main thread, before the first
 *      HUD load), set the scan-requested flag and run the engine's own
 *      ArchiveSystem::Pump() (RVA 0x688BD0, switches to the cement fiber)
 *      interleaved with UpdateAllDrives() (RVA 0x6888C0, what the real-time
 *      task does every frame to dispatch file I/O) until the fiber reports
 *      idle.  All eleven .rcf files are then mounted (~100 ms).
 *   Both hooks are one-shot int3 breakpoints handled by a vectored exception
 *   handler; no game file is modified.
 *
 * Also included: CPU-affinity limiting (the classic high-core-count crash of
 * older builds), a crash logger and optional file-I/O tracing.
 *
 * Loaded automatically because prototype2engine.dll imports dbghelp.dll and
 * Windows searches the game folder first. Settings: Prototype2Fix.ini.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <dbghelp.h>
#include <tlhelp32.h>
#include <intrin.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#define P2FIX_VERSION "1.1"

/* ---------- supported engine build ---------- */
#define ENG_TIMESTAMP        0x68B09A3Aul  /* prototype2engine.dll PE TimeDateStamp */
#define RVA_ARCHIVE_INIT     0x689320      /* ArchiveSystem::Init(initStruct*)      */
#define RVA_AFTER_INIT       0x685600      /* Startup: instruction after call Init  */
#define RVA_PUMP             0x688BD0      /* ArchiveSystem::Pump() -> bool idle    */
#define RVA_UPDATE_DRIVES    0x6888C0      /* UpdateAllDrives()                     */
#define RVA_SCAN_REQUESTED   0xE19864      /* DWORD: cement fiber has work          */
#define RVA_LOCK_COUNT       0xE1986C      /* DWORD: sLockCount                     */
#define INIT_SCANDIR_OFFSET  0x130         /* char[] "downloads" in the init struct */
static const BYTE k_initEntryBytes[]  = { 0x53, 0x56 };                   /* push ebx; push esi      */
static const BYTE k_afterInitBytes[]  = { 0x68, 0xC4, 0xF9, 0xAA, 0x10 }; /* push "NoGameState"      */

/* ---------- settings ---------- */
static int   g_mountFix = 1;
static DWORD g_maxCores = 8;
static int   g_limitAffinity = 1;
static int   g_fakeAffinity = 1;
static int   g_crashLog = 1;
static int   g_log = 1;
static int   g_trace = 0;

static char  g_dir[MAX_PATH];
static char  g_logPath[MAX_PATH];
static BYTE* g_engBase;

static void Log(const char* fmt, ...)
{
    FILE* f; va_list ap;
    if (!g_log) return;
    f = fopen(g_logPath, "a");
    if (!f) return;
    va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
    fputc('\n', f); fclose(f);
}

/* ---------- real dbghelp forwarding ---------- */
static HMODULE g_realDbgHelp;
static FARPROC g_pStackWalk64, g_pSymFunctionTableAccess64, g_pSymGetModuleBase64;
typedef BOOL (WINAPI *StackWalk64_t)(DWORD, HANDLE, HANDLE, void*, void*, void*, void*, void*, void*);
typedef void* (WINAPI *SymFTA64_t)(HANDLE, DWORD64);
typedef DWORD64 (WINAPI *SymGMB64_t)(HANDLE, DWORD64);
typedef BOOL (WINAPI *SymInitialize_t)(HANDLE, const char*, BOOL);

static void LoadRealDbgHelp(void)
{
    char path[MAX_PATH];
    UINT n = GetSystemDirectoryA(path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH - 16) return;
    lstrcatA(path, "\\dbghelp.dll");
    g_realDbgHelp = LoadLibraryA(path);
    if (!g_realDbgHelp) { Log("ERROR: could not load %s (%lu)", path, GetLastError()); return; }
    g_pStackWalk64              = GetProcAddress(g_realDbgHelp, "StackWalk64");
    g_pSymFunctionTableAccess64 = GetProcAddress(g_realDbgHelp, "SymFunctionTableAccess64");
    g_pSymGetModuleBase64       = GetProcAddress(g_realDbgHelp, "SymGetModuleBase64");
}
BOOL WINAPI StackWalk64(DWORD mt, HANDLE hp, HANDLE ht, void* sf, void* ctx, void* a, void* b, void* c, void* d)
{
    if (!g_pStackWalk64) return FALSE;
    return ((StackWalk64_t)g_pStackWalk64)(mt, hp, ht, sf, ctx, a, b, c, d);
}
void* WINAPI SymFunctionTableAccess64(HANDLE hp, DWORD64 addr)
{
    if (!g_pSymFunctionTableAccess64) return NULL;
    return ((SymFTA64_t)g_pSymFunctionTableAccess64)(hp, addr);
}
DWORD64 WINAPI SymGetModuleBase64(HANDLE hp, DWORD64 addr)
{
    if (!g_pSymGetModuleBase64) return 0;
    return ((SymGMB64_t)g_pSymGetModuleBase64)(hp, addr);
}

/* ---------- helpers ---------- */
static const char* ModName(void* addr, DWORD_PTR* offset)
{
    static char mn[MAX_PATH];
    HMODULE mod = NULL;
    *offset = 0;
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)addr, &mod) && mod) {
        char full[MAX_PATH]; const char* p;
        GetModuleFileNameA(mod, full, MAX_PATH);
        p = full + lstrlenA(full);
        while (p > full && p[-1] != '\\') p--;
        lstrcpyA(mn, p);
        *offset = (DWORD_PTR)((BYTE*)addr - (BYTE*)mod);
        return mn;
    }
    return "?";
}

static int ReadableString(const void* p, char* out, int max)
{
    int n = 0; MEMORY_BASIC_INFORMATION mbi;
    if (!p || VirtualQuery(p, &mbi, sizeof(mbi)) == 0) return 0;
    if (mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return 0;
    for (n = 0; n < max - 1; n++) {
        const BYTE* b = (const BYTE*)p + n;
        if ((BYTE*)b >= (BYTE*)mbi.BaseAddress + mbi.RegionSize) break;
        if (*b == 0) break;
        if (*b < 0x20 || *b > 0x7e) return 0;
        out[n] = (char)*b;
    }
    out[n] = 0;
    return n >= 4 ? n : 0;
}

/* Patch the import address table of `mod` so dllName!funcName goes to `hook`. */
static int PatchIAT(HMODULE mod, const char* dllName, const char* funcName, void* hook)
{
    BYTE* base = (BYTE*)mod; IMAGE_DOS_HEADER* dos; IMAGE_NT_HEADERS* nt;
    IMAGE_DATA_DIRECTORY dir; IMAGE_IMPORT_DESCRIPTOR* imp; int patched = 0;
    if (!mod) return 0;
    dos = (IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;
    dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir.VirtualAddress) return 0;
    imp = (IMAGE_IMPORT_DESCRIPTOR*)(base + dir.VirtualAddress);
    for (; imp->Name; imp++) {
        const char* name = (const char*)(base + imp->Name);
        IMAGE_THUNK_DATA *thunkNames, *thunkAddrs;
        if (lstrcmpiA(name, dllName) != 0) continue;
        thunkNames = (IMAGE_THUNK_DATA*)(base + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
        thunkAddrs = (IMAGE_THUNK_DATA*)(base + imp->FirstThunk);
        for (; thunkNames->u1.AddressOfData; thunkNames++, thunkAddrs++) {
            IMAGE_IMPORT_BY_NAME* ibn; DWORD old;
            if (thunkNames->u1.Ordinal & IMAGE_ORDINAL_FLAG) continue;
            ibn = (IMAGE_IMPORT_BY_NAME*)(base + thunkNames->u1.AddressOfData);
            if (lstrcmpA((const char*)ibn->Name, funcName) != 0) continue;
            if (!VirtualProtect(&thunkAddrs->u1.Function, sizeof(void*), PAGE_READWRITE, &old)) continue;
            thunkAddrs->u1.Function = (DWORD_PTR)hook;
            VirtualProtect(&thunkAddrs->u1.Function, sizeof(void*), old, &old);
            patched++;
        }
    }
    return patched;
}

/* ---------- affinity (classic high-core-count crash of older builds) ---------- */
static DWORD_PTR ClampMask(DWORD_PTR mask, DWORD maxBits)
{
    DWORD_PTR out = 0; DWORD n = 0; int i;
    for (i = 0; i < (int)(sizeof(DWORD_PTR) * 8) && n < maxBits; i++)
        if (mask & ((DWORD_PTR)1 << i)) { out |= ((DWORD_PTR)1 << i); n++; }
    return out ? out : mask;
}
typedef BOOL (WINAPI *GetProcessAffinityMask_t)(HANDLE, PDWORD_PTR, PDWORD_PTR);
static GetProcessAffinityMask_t g_origGetProcessAffinityMask;
static BOOL WINAPI Hook_GetProcessAffinityMask(HANDLE hProcess, PDWORD_PTR pProc, PDWORD_PTR pSys)
{
    BOOL ok = g_origGetProcessAffinityMask(hProcess, pProc, pSys);
    if (ok && pProc) {
        *pProc = ClampMask(*pProc, g_maxCores);
        if (pSys) *pSys = ClampMask(*pSys, g_maxCores);
    }
    return ok;
}
static void ApplyAffinityFix(void)
{
    DWORD_PTR procMask = 0, sysMask = 0, newMask; SYSTEM_INFO si;
    GetProcessAffinityMask(GetCurrentProcess(), &procMask, &sysMask);
    GetSystemInfo(&si);
    Log("System: %lu logical processors, process mask 0x%08lX", si.dwNumberOfProcessors, (unsigned long)procMask);
    newMask = ClampMask(procMask, g_maxCores);
    if (g_limitAffinity && newMask != procMask) {
        if (SetProcessAffinityMask(GetCurrentProcess(), newMask))
            Log("SetProcessAffinityMask -> 0x%08lX (MaxCores=%lu)", (unsigned long)newMask, g_maxCores);
        else Log("ERROR: SetProcessAffinityMask failed (%lu)", GetLastError());
    }
    if (g_fakeAffinity) {
        int n = 0;
        g_origGetProcessAffinityMask = (GetProcessAffinityMask_t)GetProcAddress(GetModuleHandleA("kernel32.dll"), "GetProcessAffinityMask");
        if (g_origGetProcessAffinityMask) {
            n += PatchIAT(GetModuleHandleA("prototype2engine.dll"), "KERNEL32.dll", "GetProcessAffinityMask", (void*)Hook_GetProcessAffinityMask);
            n += PatchIAT(GetModuleHandleA(NULL),                   "KERNEL32.dll", "GetProcessAffinityMask", (void*)Hook_GetProcessAffinityMask);
        }
        Log("GetProcessAffinityMask hook: %d entries", n);
    }
}

/* ---------- optional file-I/O tracing (TraceFiles=1) ---------- */
typedef HANDLE (WINAPI *CreateFileA_t)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
typedef HANDLE (WINAPI *FindFirstFileA_t)(LPCSTR, LPWIN32_FIND_DATAA);
typedef BOOL   (WINAPI *ReadFile_t)(HANDLE, LPVOID, DWORD, LPDWORD, LPOVERLAPPED);
typedef void   (WINAPI *OutputDebugStringA_t)(LPCSTR);
static CreateFileA_t g_oCreateFileA; static FindFirstFileA_t g_oFindFirstFileA;
static ReadFile_t g_oReadFile; static OutputDebugStringA_t g_oOutputDebugStringA;

static HANDLE WINAPI H_CreateFileA(LPCSTR n, DWORD acc, DWORD sh, LPSECURITY_ATTRIBUTES sa, DWORD disp, DWORD fl, HANDLE t)
{
    HANDLE h = g_oCreateFileA(n, acc, sh, sa, disp, fl, t);
    DWORD e = (h == INVALID_HANDLE_VALUE) ? GetLastError() : 0;
    Log("CreateFileA(\"%s\") -> %s%lu", n ? n : "(null)", h == INVALID_HANDLE_VALUE ? "FAILED err=" : "ok ", e);
    if (h == INVALID_HANDLE_VALUE) SetLastError(e);
    return h;
}
static HANDLE WINAPI H_FindFirstFileA(LPCSTR n, LPWIN32_FIND_DATAA fd)
{
    HANDLE h = g_oFindFirstFileA(n, fd);
    DWORD e = (h == INVALID_HANDLE_VALUE) ? GetLastError() : 0;
    Log("FindFirstFileA(\"%s\") -> %s%lu", n ? n : "(null)", h == INVALID_HANDLE_VALUE ? "FAILED err=" : "ok ", e);
    if (h == INVALID_HANDLE_VALUE) SetLastError(e);
    return h;
}
static BOOL WINAPI H_ReadFile(HANDLE h, LPVOID buf, DWORD n, LPDWORD got, LPOVERLAPPED ov)
{
    BOOL ok = g_oReadFile(h, buf, n, got, ov);
    DWORD e = ok ? 0 : GetLastError();
    Log("ReadFile(h=%p, %lu bytes) -> %s %lu", h, n, ok ? "ok" : "FAILED err=", ok ? (got ? *got : 0) : e);
    if (!ok) SetLastError(e);
    return ok;
}
static void WINAPI H_OutputDebugStringA(LPCSTR s) { Log("ODS: %s", s ? s : "(null)"); g_oOutputDebugStringA(s); }

static void InstallTraceHooks(void)
{
    HMODULE eng = GetModuleHandleA("prototype2engine.dll");
    HMODULE k32 = GetModuleHandleA("kernel32.dll");
    int n = 0;
    if (!eng) return;
    g_oCreateFileA        = (CreateFileA_t)GetProcAddress(k32, "CreateFileA");
    g_oFindFirstFileA     = (FindFirstFileA_t)GetProcAddress(k32, "FindFirstFileA");
    g_oReadFile           = (ReadFile_t)GetProcAddress(k32, "ReadFile");
    g_oOutputDebugStringA = (OutputDebugStringA_t)GetProcAddress(k32, "OutputDebugStringA");
    n += PatchIAT(eng, "KERNEL32.dll", "CreateFileA",        (void*)H_CreateFileA);
    n += PatchIAT(eng, "KERNEL32.dll", "FindFirstFileA",     (void*)H_FindFirstFileA);
    n += PatchIAT(eng, "KERNEL32.dll", "ReadFile",           (void*)H_ReadFile);
    n += PatchIAT(eng, "KERNEL32.dll", "OutputDebugStringA", (void*)H_OutputDebugStringA);
    n += PatchIAT(GetModuleHandleA(NULL), "KERNEL32.dll", "OutputDebugStringA", (void*)H_OutputDebugStringA);
    Log("trace hooks installed: %d", n);
}

/* ---------- the archive mount fix ---------- */
typedef char (__cdecl *Pump_t)(void);
typedef void (__cdecl *UpdateAllDrives_t)(void);
static DWORD g_resumeAddr;

static void __cdecl DoMountAll(void)
{
    Pump_t pump = (Pump_t)(g_engBase + RVA_PUMP);
    UpdateAllDrives_t updateDrives = (UpdateAllDrives_t)(g_engBase + RVA_UPDATE_DRIVES);
    DWORD* scanRequested = (DWORD*)(g_engBase + RVA_SCAN_REQUESTED);
    DWORD* lockCount = (DWORD*)(g_engBase + RVA_LOCK_COUNT);
    int i; char idle = 0; DWORD t0 = GetTickCount();

    Log("mountfix: requesting archive scan of game folder (scanRequested=%lu lockCount=%lu)", *scanRequested, *lockCount);
    *scanRequested = 1;
    for (i = 0; i < 5000; i++) {        /* ~100 ms normally; 5 s hard cap */
        idle = pump();                  /* run the cement fiber until it yields */
        if (idle) break;
        updateDrives();                 /* dispatch queued file I/O, deliver completions */
        Sleep(1);
    }
    Log("mountfix: %s after %d pump iterations, %lu ms (scanRequested=%lu)",
        idle ? "archives mounted" : "TIMEOUT - archives may be missing", i, GetTickCount() - t0, *scanRequested);
}

static __declspec(naked) void MountTrampoline(void)
{
    __asm {
        pushad
        pushfd
        call DoMountAll
        popfd
        popad
        jmp dword ptr [g_resumeAddr]
    }
}

static void PatchInitStruct(BYTE* st)
{
    char* dir = (char*)(st + INIT_SCANDIR_OFFSET);
    if (IsBadWritePtr(dir, 16)) { Log("mountfix: init struct unreadable"); return; }
    Log("mountfix: archive scan dir \"%s\" -> \".\"", dir);
    lstrcpyA(dir, ".");
}

/* one-shot int3 breakpoints */
typedef struct { DWORD rva; const char* name; const BYTE* expect; int nexpect; BYTE orig; int armed; } BreakPt;
static BreakPt g_bp[] = {
    { RVA_ARCHIVE_INIT, "ArchiveSystem::Init", k_initEntryBytes, sizeof(k_initEntryBytes) },
    { RVA_AFTER_INIT,   "after ArchiveInit",   k_afterInitBytes, sizeof(k_afterInitBytes) },
};

static int VerifyBuild(void)
{
    IMAGE_DOS_HEADER* dos; IMAGE_NT_HEADERS* nt; size_t i;
    if (!g_engBase) { Log("mountfix: prototype2engine.dll not loaded"); return 0; }
    dos = (IMAGE_DOS_HEADER*)g_engBase; nt = (IMAGE_NT_HEADERS*)(g_engBase + dos->e_lfanew);
    if (nt->FileHeader.TimeDateStamp != ENG_TIMESTAMP) {
        Log("mountfix: UNSUPPORTED engine build (timestamp 0x%08lX, expected 0x%08lX) - fix disabled",
            (unsigned long)nt->FileHeader.TimeDateStamp, (unsigned long)ENG_TIMESTAMP);
        return 0;
    }
    for (i = 0; i < sizeof(g_bp) / sizeof(g_bp[0]); i++) {
        if (memcmp(g_engBase + g_bp[i].rva, g_bp[i].expect, g_bp[i].nexpect) != 0) {
            Log("mountfix: unexpected code at %s (RVA 0x%lX) - fix disabled", g_bp[i].name, (unsigned long)g_bp[i].rva);
            return 0;
        }
    }
    return 1;
}

static void ArmBreakpoints(void)
{
    size_t i; int n = 0;
    for (i = 0; i < sizeof(g_bp) / sizeof(g_bp[0]); i++) {
        BYTE* p = g_engBase + g_bp[i].rva; DWORD old;
        if (!VirtualProtect(p, 1, PAGE_EXECUTE_READWRITE, &old)) { Log("bp %s: VirtualProtect failed", g_bp[i].name); continue; }
        g_bp[i].orig = *p; *p = 0xCC; g_bp[i].armed = 1; n++;
        VirtualProtect(p, 1, old, &old);
        FlushInstructionCache(GetCurrentProcess(), p, 1);
    }
    Log("mountfix: %d breakpoints armed", n);
}

static LONG HandleBreakpoint(EXCEPTION_POINTERS* ep)
{
    BYTE* addr = (BYTE*)ep->ExceptionRecord->ExceptionAddress;
    size_t i;
    if (!g_engBase) return EXCEPTION_CONTINUE_SEARCH;
    for (i = 0; i < sizeof(g_bp) / sizeof(g_bp[0]); i++) {
        if (g_bp[i].armed && addr == g_engBase + g_bp[i].rva) {
            CONTEXT* c = ep->ContextRecord; DWORD old;
            DWORD* sp = (DWORD*)c->Esp;
            VirtualProtect(addr, 1, PAGE_EXECUTE_READWRITE, &old);
            *addr = g_bp[i].orig; g_bp[i].armed = 0;
            VirtualProtect(addr, 1, old, &old);
            FlushInstructionCache(GetCurrentProcess(), addr, 1);
            c->Eip = (DWORD)(DWORD_PTR)addr;              /* re-execute the original instruction */
            if (g_bp[i].rva == RVA_ARCHIVE_INIT) {
                if (!IsBadReadPtr(sp + 1, 4)) PatchInitStruct((BYTE*)sp[1]);   /* arg1 = init struct */
            } else if (g_bp[i].rva == RVA_AFTER_INIT) {
                g_resumeAddr = (DWORD)(DWORD_PTR)addr;
                c->Eip = (DWORD)(DWORD_PTR)MountTrampoline; /* mount, then continue at addr */
            }
            return EXCEPTION_CONTINUE_EXECUTION;
        }
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

/* ---------- crash logger ---------- */
static void DumpThreads(FILE* f)
{
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    THREADENTRY32 te; DWORD me = GetCurrentThreadId(), pid = GetCurrentProcessId(); DWORD_PTR off;
    te.dwSize = sizeof(te);
    fprintf(f, "  other threads:\n");
    if (snap != INVALID_HANDLE_VALUE && Thread32First(snap, &te)) {
        do {
            HANDLE th; CONTEXT tc;
            if (te.th32OwnerProcessID != pid || te.th32ThreadID == me) continue;
            th = OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION, FALSE, te.th32ThreadID);
            if (!th) continue;
            if (SuspendThread(th) != (DWORD)-1) {
                tc.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER;
                if (GetThreadContext(th, &tc)) {
                    const char* m = ModName((void*)tc.Eip, &off);
                    DWORD* sp = (DWORD*)tc.Esp; int i, shown = 0;
                    fprintf(f, "    tid=%-6lu eip=%08lX %s+0x%lX", te.th32ThreadID, tc.Eip, m, (unsigned long)off);
                    for (i = 0; i < 64 && shown < 6; i++) {
                        DWORD_PTR o2; const char* m2;
                        if (IsBadReadPtr(sp + i, 4)) break;
                        m2 = ModName((void*)sp[i], &o2);
                        if (o2 && lstrcmpiA(m2, "prototype2engine.dll") == 0) { fprintf(f, " <%lX", (unsigned long)o2); shown++; }
                    }
                    fputc('\n', f);
                }
                ResumeThread(th);
            }
            CloseHandle(th);
        } while (Thread32Next(snap, &te));
    }
    if (snap != INVALID_HANDLE_VALUE) CloseHandle(snap);
}

static void DumpCrash(FILE* f, EXCEPTION_POINTERS* ep, const char* kind)
{
    EXCEPTION_RECORD* er = ep->ExceptionRecord; CONTEXT* c = ep->ContextRecord;
    DWORD_PTR off, pm = 0, sm = 0; const char* m; SYSTEMTIME st;
    GetLocalTime(&st);
    fprintf(f, "\n[%04d-%02d-%02d %02d:%02d:%02d] Prototype2Fix %s: %s exception 0x%08lX at %p\n",
            st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, P2FIX_VERSION, kind,
            er->ExceptionCode, er->ExceptionAddress);
    if (er->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && er->NumberParameters >= 2)
        fprintf(f, "  access violation: %s address %p\n", er->ExceptionInformation[0] ? "write to" : "read of",
                (void*)er->ExceptionInformation[1]);
    m = ModName(er->ExceptionAddress, &off);
    fprintf(f, "  module: %s + 0x%lX\n", m, (unsigned long)off);
    fprintf(f, "  eax=%08lX ebx=%08lX ecx=%08lX edx=%08lX esi=%08lX edi=%08lX ebp=%08lX esp=%08lX eip=%08lX\n",
            c->Eax, c->Ebx, c->Ecx, c->Edx, c->Esi, c->Edi, c->Ebp, c->Esp, c->Eip);
    GetProcessAffinityMask(GetCurrentProcess(), &pm, &sm);
    fprintf(f, "  process affinity: 0x%08lX\n", (unsigned long)pm);
    {   /* raw stack: return addresses and strings */
        DWORD* sp = (DWORD*)c->Esp; int i; char s[96];
        fprintf(f, "  stack (esp=%08lX):\n", c->Esp);
        for (i = 0; i < 96; i++) {
            DWORD v;
            if (IsBadReadPtr(sp + i, 4)) break;
            v = sp[i];
            if (v < 0x10000) continue;
            m = ModName((void*)v, &off);
            if (off) { fprintf(f, "    [%02X] %08lX  %s+0x%lX\n", i * 4, v, m, (unsigned long)off); continue; }
            if (ReadableString((void*)v, s, sizeof(s))) fprintf(f, "    [%02X] %08lX  \"%s\"\n", i * 4, v, s);
        }
    }
    DumpThreads(f);
    if (g_pStackWalk64 && g_pSymFunctionTableAccess64 && g_pSymGetModuleBase64) {
        STACKFRAME64 sf; CONTEXT cc = *c; int n = 0;
        SymInitialize_t init = (SymInitialize_t)GetProcAddress(g_realDbgHelp, "SymInitialize");
        if (init) init(GetCurrentProcess(), NULL, TRUE);
        ZeroMemory(&sf, sizeof(sf));
        sf.AddrPC.Offset = cc.Eip;    sf.AddrPC.Mode = AddrModeFlat;
        sf.AddrFrame.Offset = cc.Ebp; sf.AddrFrame.Mode = AddrModeFlat;
        sf.AddrStack.Offset = cc.Esp; sf.AddrStack.Mode = AddrModeFlat;
        fprintf(f, "  call stack:\n");
        while (n++ < 40 && ((StackWalk64_t)g_pStackWalk64)(IMAGE_FILE_MACHINE_I386, GetCurrentProcess(), GetCurrentThread(),
               &sf, &cc, NULL, (void*)g_pSymFunctionTableAccess64, (void*)g_pSymGetModuleBase64, NULL)) {
            if (!sf.AddrPC.Offset) break;
            m = ModName((void*)(DWORD_PTR)sf.AddrPC.Offset, &off);
            fprintf(f, "    %s+0x%lX\n", m, (unsigned long)off);
        }
    }
    fflush(f);
}

static LONG g_crashLogged = 0;
static LONG WINAPI CrashFilter(EXCEPTION_POINTERS* ep)
{
    char path[MAX_PATH]; FILE* f;
    lstrcpyA(path, g_dir); lstrcatA(path, "Prototype2Fix_crash.log");
    f = fopen(path, "a");
    if (f) { DumpCrash(f, ep, "Unhandled"); fclose(f); }
    return EXCEPTION_CONTINUE_SEARCH;
}
static LONG WINAPI VectoredHandler(EXCEPTION_POINTERS* ep)
{
    DWORD code = ep->ExceptionRecord->ExceptionCode;
    if (code == EXCEPTION_BREAKPOINT) return HandleBreakpoint(ep);
    if (g_crashLog && (code == EXCEPTION_ACCESS_VIOLATION || code == EXCEPTION_ILLEGAL_INSTRUCTION ||
        code == EXCEPTION_STACK_OVERFLOW || code == EXCEPTION_INT_DIVIDE_BY_ZERO || code == EXCEPTION_PRIV_INSTRUCTION)) {
        if (InterlockedIncrement(&g_crashLogged) <= 3) {
            char path[MAX_PATH]; FILE* f;
            lstrcpyA(path, g_dir); lstrcatA(path, "Prototype2Fix_crash.log");
            f = fopen(path, "a");
            if (f) { DumpCrash(f, ep, "First-chance"); fclose(f); }
        }
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

/* ---------- ini ---------- */
static void ReadSettings(void)
{
    char ini[MAX_PATH];
    lstrcpyA(ini, g_dir); lstrcatA(ini, "Prototype2Fix.ini");
    g_mountFix      = GetPrivateProfileIntA("Prototype2Fix", "MountFix", 1, ini);
    g_maxCores      = GetPrivateProfileIntA("Prototype2Fix", "MaxCores", 8, ini);
    g_limitAffinity = GetPrivateProfileIntA("Prototype2Fix", "LimitProcessAffinity", 1, ini);
    g_fakeAffinity  = GetPrivateProfileIntA("Prototype2Fix", "FakeAffinityMask", 1, ini);
    g_crashLog      = GetPrivateProfileIntA("Prototype2Fix", "CrashLog", 1, ini);
    g_log           = GetPrivateProfileIntA("Prototype2Fix", "Log", 1, ini);
    g_trace         = GetPrivateProfileIntA("Prototype2Fix", "TraceFiles", 0, ini);
    if (g_maxCores < 1) g_maxCores = 1;
    if (g_maxCores > 64) g_maxCores = 64;
}

BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID reserved)
{
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        char* p;
        DisableThreadLibraryCalls(hinst);
        GetModuleFileNameA(hinst, g_dir, MAX_PATH);
        p = g_dir + lstrlenA(g_dir);
        while (p > g_dir && p[-1] != '\\' && p[-1] != '/') p--;
        *p = 0;
        lstrcpyA(g_logPath, g_dir); lstrcatA(g_logPath, "Prototype2Fix.log");
        ReadSettings();
        DeleteFileA(g_logPath);
        Log("Prototype2Fix %s loaded (MountFix=%d MaxCores=%lu LimitProcessAffinity=%d FakeAffinityMask=%d CrashLog=%d TraceFiles=%d)",
            P2FIX_VERSION, g_mountFix, g_maxCores, g_limitAffinity, g_fakeAffinity, g_crashLog, g_trace);
        Log("Command line: %s", GetCommandLineA());
        LoadRealDbgHelp();
        g_engBase = (BYTE*)GetModuleHandleA("prototype2engine.dll");
        ApplyAffinityFix();
        if (g_trace) InstallTraceHooks();
        if (g_crashLog || g_mountFix) {
            SetUnhandledExceptionFilter(CrashFilter);
            AddVectoredExceptionHandler(1, VectoredHandler);
        }
        if (g_mountFix && VerifyBuild()) ArmBreakpoints();
    } else if (reason == DLL_PROCESS_DETACH) {
        if (g_realDbgHelp) FreeLibrary(g_realDbgHelp);
    }
    return TRUE;
}
